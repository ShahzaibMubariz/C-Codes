﻿using PracProj.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace PracProj.Controllers
{
    public class HomeController : Controller
    {

        EHREntities db = new EHREntities();
        // GET: Home
        public ActionResult Index()
        {
            
          var LabTest=  db.LabTests.ToList();
            var LabTests = db.LabTests.Where(x => x.TestID == 3).FirstOrDefault();
            ViewBag.LabList=  new SelectList(LabTest, "TestID", "TestName", LabTests.TestID);
           
           
            return View(LabTests);
        }



        }

    }
